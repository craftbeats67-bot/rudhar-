package com.rudhar.ai;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.AlarmClock;
import android.provider.CalendarContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

public class MainActivity extends Activity {
  private WebView web;
  private TextToSpeech tts;
  private static final int REQ_VOICE = 41;
  private static final int REQ_PERM = 42;
  private static final HashMap<String, String> PKG = new HashMap<String, String>();
  static {
    PKG.put("youtube", "com.google.android.youtube");
    PKG.put("chrome", "com.android.chrome");
    PKG.put("google", "com.google.android.googlequicksearchbox");
    PKG.put("gmail", "com.google.android.gm");
    PKG.put("maps", "com.google.android.apps.maps");
    PKG.put("google maps", "com.google.android.apps.maps");
    PKG.put("whatsapp", "com.whatsapp");
    PKG.put("instagram", "com.instagram.android");
    PKG.put("facebook", "com.facebook.katana");
    PKG.put("telegram", "org.telegram.messenger");
    PKG.put("spotify", "com.spotify.music");
    PKG.put("netflix", "com.netflix.mediaclient");
    PKG.put("play store", "com.android.vending");
    PKG.put("playstore", "com.android.vending");
    PKG.put("photos", "com.google.android.apps.photos");
    PKG.put("termux", "com.termux");
    PKG.put("camera", "com.android.camera");
    PKG.put("calculator", "com.google.android.calculator");
    PKG.put("clock", "com.google.android.deskclock");
  }

  @Override
  protected void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    setContentView(web);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(false);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient() {
      @Override
      public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        return handleUrl(r.getUrl().toString());
      }
    });
    web.addJavascriptInterface(new Bridge(), "Phone");
    tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
      @Override
      public void onInit(int st) {
        if (st == TextToSpeech.SUCCESS && tts != null) tts.setLanguage(new Locale("hi", "IN"));
      }
    });
    web.loadUrl("file:///android_asset/index.html");
  }

  @Override
  public void onBackPressed() {
    if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
  }

  @Override
  protected void onDestroy() {
    if (tts != null) { tts.shutdown(); tts = null; }
    super.onDestroy();
  }

  private void toast(final String m) {
    runOnUiThread(new Runnable() { public void run() { Toast.makeText(MainActivity.this, m, Toast.LENGTH_SHORT).show(); } });
  }

  // Sirf apni local file WebView mein khulti hai. Baaki sab links bahar (browser/app) mein khulte hain,
  // taaki koi website Phone bridge tak na pahunch sake.
  private boolean handleUrl(String u) {
    if (u.startsWith("file:///android_asset/")) return false;
    try {
      if (u.startsWith("intent:")) {
        Intent i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME);
        i.setComponent(null);
        i.setSelector(null);
        try {
          startActivity(i);
        } catch (ActivityNotFoundException e) {
          String fb = i.getStringExtra("browser_fallback_url");
          if (fb != null && (fb.startsWith("https://") || fb.startsWith("http://"))) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(fb)));
          } else {
            toast("App ya setting nahi mili");
          }
        }
      } else {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
      }
    } catch (Exception e) {
      toast("Link nahi khula");
    }
    return true;
  }

  private void callJs(final String js) {
    runOnUiThread(new Runnable() { public void run() { web.evaluateJavascript(js, null); } });
  }

  @Override
  protected void onActivityResult(int req, int res, Intent data) {
    super.onActivityResult(req, res, data);
    if (req == REQ_VOICE) {
      String text = "";
      if (res == RESULT_OK && data != null) {
        ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (r != null && !r.isEmpty()) text = r.get(0);
      }
      callJs("window.onVoice&&window.onVoice(" + JSONObject.quote(text) + ")");
    }
  }

  private String save(String name, byte[] data) {
    try {
      String safe = name.replaceAll("[^A-Za-z0-9._-]", "_");
      ContentValues v = new ContentValues();
      v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
      v.put(MediaStore.MediaColumns.MIME_TYPE, safe.endsWith(".zip") ? "application/zip" : "text/plain");
      v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
      Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
      if (u == null) return "error";
      OutputStream os = getContentResolver().openOutputStream(u);
      if (os == null) return "error";
      os.write(data);
      os.close();
      return "saved:" + safe;
    } catch (Exception e) {
      return "error:" + e.getMessage();
    }
  }

  private String start(Intent i) {
    try {
      startActivity(i);
      return "ok";
    } catch (Exception e) {
      return "error";
    }
  }

  public class Bridge {
    @JavascriptInterface public void openNotifAccess() { }
    @JavascriptInterface
    public String status() { return RudharService.instance != null ? "on" : "off"; }

    @JavascriptInterface
    public void openAccessibility() {
      Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      start(i);
    }

    @JavascriptInterface
    public String screen() {
      RudharService s = RudharService.instance;
      return s == null ? "{\"pkg\":\"\",\"els\":[]}" : s.screen();
    }

    @JavascriptInterface
    public String tap(int i) {
      RudharService s = RudharService.instance;
      return s == null ? "Accessibility OFF hai" : s.tap(i);
    }

    @JavascriptInterface
    public String type(String t) {
      RudharService s = RudharService.instance;
      return s == null ? "Accessibility OFF hai" : s.typeText(t);
    }

    @JavascriptInterface
    public String key(String k) {
      RudharService s = RudharService.instance;
      return s == null ? "Accessibility OFF hai" : s.key(k);
    }

    @JavascriptInterface
    public String swipe(String d) {
      RudharService s = RudharService.instance;
      return s == null ? "Accessibility OFF hai" : s.swipe(d);
    }

    @JavascriptInterface
    public void front() {
      Intent i = new Intent(MainActivity.this, MainActivity.class);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
      start(i);
    }

    @JavascriptInterface
    public void hide() {
      runOnUiThread(new Runnable() { public void run() { moveTaskToBack(true); } });
    }

    @JavascriptInterface public String notifAccess() { return "off"; }
    @JavascriptInterface public String notifications() { return "[]"; }
    @JavascriptInterface public String contacts(String name) { return "[]"; }
    @JavascriptInterface public String termux(String cmd) { return "unsupported"; }
    @JavascriptInterface public String termuxRun(String cmd, String id) { return "unsupported"; }
    @JavascriptInterface public String remind(String at, String text, boolean daily, int code) { return "unsupported"; }
    @JavascriptInterface public String cancelRemind(int code) { return "unsupported"; }

    @JavascriptInterface
    public void openAppSettings() {
      start(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
    }

    @JavascriptInterface
    public void askPerms() {
      if (Build.VERSION.SDK_INT >= 33) {
        runOnUiThread(new Runnable() { public void run() { requestPermissions(new String[] { Manifest.permission.POST_NOTIFICATIONS }, REQ_PERM); } });
      }
    }

    @JavascriptInterface
    public String perms() {
      boolean notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
      return "{\"access\":" + (RudharService.instance != null) + ",\"mic\":true,\"notify\":" + notif + ",\"call\":true,\"contacts\":false,\"storage\":true,\"sms\":true,\"termux\":false}";
    }

    @JavascriptInterface
    public String openApp(String name) {
      String n = name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
      if (n.length() < 2) return "not_found:" + name;
      if (n.equals("settings") || n.equals("setting")) {
        Intent si = new Intent(Settings.ACTION_SETTINGS);
        si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return start(si).equals("ok") ? "opened:Settings" : "error:Settings";
      }
      PackageManager pm = getPackageManager();
      Intent li = null;
      String pkg = PKG.get(n);
      if (pkg != null) li = pm.getLaunchIntentForPackage(pkg);
      if (li == null) {
        Intent q = new Intent(Intent.ACTION_MAIN);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
          String label = String.valueOf(ri.loadLabel(pm)).toLowerCase(Locale.ROOT);
          if (label.equals(n) || label.contains(n)) {
            li = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
            if (li != null) break;
          }
        }
      }
      if (li == null) return "not_found:" + name;
      li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      return start(li).equals("ok") ? "opened:" + name : "error:" + name;
    }

    @JavascriptInterface
    public void listen() {
      runOnUiThread(new Runnable() {
        public void run() {
          try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo...");
            startActivityForResult(i, REQ_VOICE);
          } catch (Exception e) {
            toast("Voice recognition (Google app) nahi mili");
            callJs("window.onVoice&&window.onVoice('')");
          }
        }
      });
    }

    @JavascriptInterface
    public void speak(final String t) {
      runOnUiThread(new Runnable() { public void run() { if (tts != null) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "rudhar"); } });
    }

    @JavascriptInterface
    public String notify(String title, String text) {
      if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return "no_perm";
      try {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("rudhar", "RUDHAR", NotificationManager.IMPORTANCE_DEFAULT));
        android.app.Notification n = new android.app.Notification.Builder(MainActivity.this, "rudhar")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text).build();
        nm.notify((int) (System.currentTimeMillis() % 100000), n);
        return "ok";
      } catch (Exception e) {
        return "error";
      }
    }

    @JavascriptInterface
    public String call(String number) {
      Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)));
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      return start(i).equals("ok") ? "Dialer khul gaya (" + number + "). Call button aap khud dabao." : "Dialer nahi khula.";
    }

    @JavascriptInterface
    public String sendSms(String number, String text) {
      Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number)));
      i.putExtra("sms_body", text);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      return start(i).equals("ok") ? "composer" : "error";
    }

    @JavascriptInterface
    public String openWhatsApp(String number, String text) {
      String num = number.replaceAll("[^0-9]", "");
      Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + num + "?text=" + Uri.encode(text)));
      i.setPackage("com.whatsapp");
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      return start(i).equals("ok") ? "opened" : "error";
    }

    @JavascriptInterface
    public String saveFile(String name, String content) {
      return save(name, content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    @JavascriptInterface
    public String saveBinary(String name, String b64) {
      try {
        return save(name, Base64.decode(b64, Base64.DEFAULT));
      } catch (Exception e) {
        return "error";
      }
    }

    @JavascriptInterface
    public String timer(int secs, String label) {
      Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
      i.putExtra(AlarmClock.EXTRA_LENGTH, secs);
      i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
      i.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      return start(i);
    }

    @JavascriptInterface
    public String alarm(int h, int mi, String label) {
      Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
      i.putExtra(AlarmClock.EXTRA_HOUR, h);
      i.putExtra(AlarmClock.EXTRA_MINUTES, mi);
      i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
      i.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      return start(i);
    }

    @JavascriptInterface
    public String calendarAdd(String title, String millis) {
      try {
        Intent i = new Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI);
        i.putExtra(CalendarContract.Events.TITLE, title);
        i.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, Long.parseLong(millis));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return start(i);
      } catch (Exception e) {
        return "error";
      }
    }
  }
}
