package com.rudhar.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

// Sirf tab kaam karta hai jab user Settings mein khud ON kare, aur sirf RUDHAR ke command par.
// Password fields ka text kabhi nahi padhta.
public class RudharService extends AccessibilityService {
  public static volatile RudharService instance;
  private final ArrayList<AccessibilityNodeInfo> nodes = new ArrayList<AccessibilityNodeInfo>();

  @Override
  protected void onServiceConnected() { instance = this; }

  @Override
  public void onAccessibilityEvent(AccessibilityEvent e) { }

  @Override
  public void onInterrupt() { }

  @Override
  public boolean onUnbind(Intent i) { instance = null; return super.onUnbind(i); }

  @Override
  public void onDestroy() { instance = null; super.onDestroy(); }

  public synchronized String screen() {
    JSONObject out = new JSONObject();
    try {
      nodes.clear();
      JSONArray els = new JSONArray();
      String pkg = "";
      AccessibilityNodeInfo root = null;
      for (int tries = 0; tries < 5 && root == null; tries++) {
        root = getRootInActiveWindow();
        if (root == null) { try { Thread.sleep(120); } catch (InterruptedException ie) { } }
      }
      if (root != null) {
        pkg = String.valueOf(root.getPackageName());
        walk(root, els, 0);
      }
      out.put("pkg", pkg);
      out.put("els", els);
    } catch (Exception e) {
      return "{\"pkg\":\"\",\"els\":[]}";
    }
    return out.toString();
  }

  private void walk(AccessibilityNodeInfo n, JSONArray els, int depth) throws Exception {
    if (n == null || depth > 40 || els.length() >= 80) return;
    if (n.isVisibleToUser()) {
      boolean pw = n.isPassword();
      CharSequence t = n.getText();
      CharSequence d = n.getContentDescription();
      String label = "";
      if (!pw) {
        if (t != null && t.length() > 0) label = t.toString();
        else if (d != null && d.length() > 0) label = d.toString();
        else if (n.getHintText() != null) label = n.getHintText().toString();
      }
      boolean click = n.isClickable() || n.isCheckable();
      boolean edit = n.isEditable();
      if (pw || edit || click || label.length() > 0) {
        JSONObject o = new JSONObject();
        o.put("i", nodes.size());
        o.put("text", label.length() > 80 ? label.substring(0, 80) : label);
        o.put("click", click);
        o.put("edit", edit);
        o.put("pw", pw);
        o.put("scroll", n.isScrollable());
        o.put("chk", n.isCheckable() && n.isChecked());
        String rid = n.getViewIdResourceName();
        if (rid != null && rid.lastIndexOf('/') >= 0) rid = rid.substring(rid.lastIndexOf('/') + 1);
        o.put("rid", rid == null ? "" : rid);
        nodes.add(n);
        els.put(o);
      }
    }
    for (int k = 0; k < n.getChildCount(); k++) walk(n.getChild(k), els, depth + 1);
  }

  public synchronized String tap(int i) {
    if (i < 0 || i >= nodes.size()) return "galat id";
    AccessibilityNodeInfo orig = nodes.get(i);
    AccessibilityNodeInfo n = orig;
    int guard = 0;
    while (n != null && !n.isClickable() && guard++ < 8) n = n.getParent();
    if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return "tap ho gaya";
    Rect r = new Rect();
    orig.getBoundsInScreen(r);
    if (r.width() > 0 && r.height() > 0 && gesture(r.centerX(), r.centerY(), r.centerX(), r.centerY(), 60)) return "tap ho gaya";
    return "tap nahi ho paya";
  }

  public synchronized String typeText(String text) {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    AccessibilityNodeInfo f = root == null ? null : root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    if (f == null || !f.isEditable()) {
      f = null;
      for (int k = 0; k < nodes.size(); k++) {
        if (nodes.get(k).isEditable()) { f = nodes.get(k); break; }
      }
    }
    if (f == null) return "input field nahi mili (pehle field par tap karo)";
    if (f.isPassword()) return "Safety: password field mein type nahi karunga";
    Bundle b = new Bundle();
    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
    if (f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) return "likh diya";
    try {
      ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
      cm.setPrimaryClip(ClipData.newPlainText("rudhar", text));
      f.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
      if (f.performAction(AccessibilityNodeInfo.ACTION_PASTE)) return "likh diya";
    } catch (Exception e) { }
    return "likh nahi paya";
  }

  public synchronized String key(String k) {
    if (k == null) return "galat key";
    k = k.toLowerCase();
    if (k.equals("back")) return performGlobalAction(GLOBAL_ACTION_BACK) ? "back ho gaya" : "back nahi hua";
    if (k.equals("home")) return performGlobalAction(GLOBAL_ACTION_HOME) ? "home ho gaya" : "home nahi hua";
    if (k.equals("recents")) return performGlobalAction(GLOBAL_ACTION_RECENTS) ? "recents khul gaya" : "recents nahi khula";
    if (k.equals("enter")) {
      if (Build.VERSION.SDK_INT >= 30) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo f = root == null ? null : root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f != null && f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId())) return "enter dabaya";
      }
      return "enter nahi ho paya";
    }
    if (k.equals("notifications")) return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ? "notifications khul gaye" : "notifications nahi khule";
    if (k.equals("quicksettings")) return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS) ? "quick settings khul gaye" : "quick settings nahi khule";
    if (k.equals("lock")) return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) ? "phone lock ho gaya" : "lock nahi hua";
    if (k.equals("screenshot")) return performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) ? "screenshot le liya" : "screenshot nahi hua";
    return "galat key";
  }

  public synchronized String swipe(String dir) {
    DisplayMetrics m = getResources().getDisplayMetrics();
    float w = m.widthPixels;
    float h = m.heightPixels;
    float x1, y1, x2, y2;
    if ("up".equals(dir)) { x1 = w / 2; x2 = w / 2; y1 = h * 0.7f; y2 = h * 0.3f; }
    else if ("down".equals(dir)) { x1 = w / 2; x2 = w / 2; y1 = h * 0.3f; y2 = h * 0.7f; }
    else if ("left".equals(dir)) { y1 = h / 2; y2 = h / 2; x1 = w * 0.8f; x2 = w * 0.2f; }
    else if ("right".equals(dir)) { y1 = h / 2; y2 = h / 2; x1 = w * 0.2f; x2 = w * 0.8f; }
    else return "galat direction";
    return gesture(x1, y1, x2, y2, 300) ? "swipe ho gaya" : "swipe nahi hua";
  }

  private boolean gesture(float x1, float y1, float x2, float y2, long ms) {
    Path p = new Path();
    p.moveTo(x1, y1);
    p.lineTo(x2, y2);
    GestureDescription g = new GestureDescription.Builder()
        .addStroke(new GestureDescription.StrokeDescription(p, 0, ms)).build();
    return dispatchGesture(g, null, null);
  }
}
